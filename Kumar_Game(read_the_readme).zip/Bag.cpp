//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include <vector>
#include "Bag.h"

using namespace std;

// construcotr initializing the variables 
Bag::Bag()
{
    numFlasks = 10;
    runes = 0;
    items.push_back("Shard"); 
} 

//returns the number of flasks the player has 
int Bag::getFlasks()
{
    return numFlasks;
}

// returns the number of runes the player has 
int Bag::getRunes()
{
    return runes;
}
    
// inc the number of flasks the player has 
void Bag::setFlasks(int flasks)
{
    numFlasks += flasks;
}

// deac the amount of flasks 
void Bag::deacFlasks(int flasks)
{
    numFlasks = numFlasks - flasks; 
}

// inc the amount of runes the player has 
void Bag::setRunes(int moreRunes)
{
    runes += moreRunes; 
} 

//sets the items in the bag
void Bag::setItems(string shard)
{
    items.push_back(shard);
}