//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include "Attack.h"
#include "Enemy.h"
#include "Character.h"
#include "time.h"
#include "Bag.h"
#include "Stat.h"
#include "Stats.h"
using namespace std; 

/**
 * takes user input string to split up by given dellimeters
 * takes in all user inputs and runs them through this function 
 * if string has no length it does nothing if not it goes through and separates the string by the delimiter
 */
int split(string inputString, char separator, string arr[], int size)
{
    for ( int i = 0; i < size; i++)
    {
        arr[i] = "";
    }
    if( inputString.length() == 0) // input validation statemnent 
    {
        return 0;
    }
    int index = 0;                  
    for (unsigned int i = 0; i < inputString.length(); i++)          // for loop loops through the string entered and validates the string
    {
        if ( index == size)     // if the 
        {
            return -1; 
        }
        else 
        {
            if ( inputString[i] == separator)       // this set of statements checks the location of separator and then separates the strings and stores them 
            {
                index++;
            }
            else 
            {
               arr[index] += inputString[i];  // separates the string 
            }
        }
    }
    return index + 1;
}

/**
 * tolower takes in a string and returns the string in all lower case letters
 * uses the string and ascii values to look for the uppercase  
 */
string ToLower(string str)
{
    string tempS = "";
    for (int i = 0; i < str.length(); i++ )
    {
        if (str[i] >= 65 && str[i] <= 90) // checks for upper case 
        {
           tempS += str[i] + 32; // converts to lowercase 
        } 
        else 
        {
            tempS += str[i];        // keeps rest of string 
        }
    }
    return tempS;
}

//reads to the file and fills the stats array with stat variable 
Stats::Stats()
{
    string line;
    string array[3];
    ifstream read;
    read.open("stats.txt");
    while(getline(read,line))
    {
        split(line, ',', array, 3);
        Stat stat(array[0], stoi(array[1]), stoi(array[2]));
        stats1.push_back(stat);
    }
    read.close();
}

//option 2 for finding recent player stats 
void Stats::option2() //read the last players stats 
{
    cout << stats1[stats1.size() - 1].toString() << endl; 
}

//read players best stats
void Stats::option3() // read best stats
{
    ifstream fin;
    string line;
    int health1 = 0;
    int runes1 = 0;
    string array[3];
    fin.open("stats.txt");
    while(getline(fin,line)) // reads from the file 
    {
        split(line, ',', array, 3);
        int r2 = stoi(array[2]);
        int h2 = stoi(array[1]);
        if (h2 > health1)
        {
            health1 = h2;
        }
        if ( r2 > runes1)           // gets both the highest values 
        {
            runes1 = r2;
        }
    }
    cout << "Highest stats ended with are: "  << endl;
    cout << "HP: " << health1 << endl;
    cout << "Runes: " << runes1 << endl; 
    fin.close();
}

//enter your name and get your most recent stats
void Stats::option4(string name) // 
{
    string nameEnter = ToLower(name); 
    int lastIndex =-1;
    for (int i = 0; i < stats1.size(); i++)     // going through each name in file/vector 
    {
        string arrayname = ToLower(stats1[i].getName());  // ToLower makes sure you enter anyhting and find it 
        if (arrayname == nameEnter)
        {
            lastIndex = i;
        }
    }
    if (lastIndex == -1)
    {
        cout << "Could not find your name." << endl; 
    }
    else 
    { 
        cout << stats1[lastIndex].toString() << endl; // reads out your stats 
    }
}

//wriytes to the file of your stats, does every death 
void Stats::addStat(Stat newStat)
{
    ofstream write; 
    write.open("stats.txt", ios_base::app);
    write << newStat.toFile() << endl;
    write.close();
    stats1.push_back(newStat);
}

