//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
#include <vector> 
#include "Bag.h"
#include "Character.h"
#include "Attack.h"
#include "Enemy.h"
#include "Map.h"
#include "Stat.h"
#include "Stats.h"
#include <clocale>

using namespace std;

/**
 * takes in the map obhject for the cave and your bag
 * function moves you through the cave till you exit
 */
Map mapCave(Map Cave, Bag BagP)
{
    int fu = 2;
    char move;
    bool doneV = false;
    Cave.spawnSite(rand()%  12,rand() % 12,1); // spawns random exit site of the cave 
    while (!doneV)
    {
        Cave.displayMap();
        cout << "Use WASD to move. E to exit cave." << endl;            // Mmoves the player 
        cin >> move; 
        if (move == 'E'|| move == 'e')
        {
            doneV = true; 
        }
        else 
        {     
            Cave.executeMove(move);
            if (Cave.isSiteLocation() == true )     // checks for when the player hits the exit 
            {
                string shard = "Shard";
                int runes = 1000;
                cout << "You have found a chest with 1000 runes!" << endl; 
                BagP.setFlasks(fu);
                BagP.setItems(shard);
                BagP.setRunes(runes);
                doneV = true; 
            }
            else 
            {
                cout << "Keep moving? Or exit?" << endl; // exits the cave when entered E 
                if ( move == 'E')
                {
                    doneV = true; 
                }
            }
        } 
    }
    return Cave;
}

/**
 * the first map in the castle and leads the pplayer to end sit e
 */
Map mapCastle(Map Castle, Bag BagP)
{
    char move1;
    bool doneC = false;
    Castle.spawnSite(rand() % 12, rand() % 12,1);   // randomly spawns the end site 
    int fo = 1;
    while (!doneC)
    {
        Castle.displayMap();
        cout << "Use WASD to move." << endl;        //moves the player 
        cin >> move1;     
        Castle.executeMove(move1);
        if (Castle.isSiteLocation() == true )       // checks for when player hits exit site 
        {
            int runes = 2000;
            cout << "You made it through, and foundn 2000 runes on the way!" << endl; 
            BagP.setFlasks(fo);
            BagP.setRunes(runes);
            doneC = true;
        } 
    }
    return Castle;
}

/**
 * walkes through the castle 
 * 
 */
int mapCastle2(Map Castle2, Character PlayerM, Bag BagP)
{
    char move1;
    bool isDead2 = false;
    bool doneC2 = false;
    int isDead = 0;
    Attack battle2;
    Castle2.spawnSite(rand() % 12, rand() % 12,1);
    Castle2.spawnMisfortune(4,2,1);     // randomly spawns the exit site and the site for ecountering the knight 
    Castle2.spawnMisfortune(6,4,1);
    int fo = 1;
    while (!doneC2)
    {
        Castle2.displayMap();
        cout << "Use WASD to move." << endl;
        cin >> move1;     
        Castle2.executeMove(move1);
        if (Castle2.isSiteLocation() == true )  // you passsed the knight safely 
        {
            int runes = 2000;
            cout << "You made it past the disgruntled knight safely." << endl; 
            doneC2 = true;
        } 
        else if ((Castle2.getPlayerColPosition() == 4 && Castle2.getPlayerRowPosition() == 1) || (Castle2.getPlayerRowPosition() == 5 && Castle2.getPlayerColPosition() == 2))
        {
            cout << "The Knight heard you! He runs at you ready to fight." << endl;         //hits the misfortune site and you fight the knight 
            isDead = battle2.Battle();
            cout << isDead << endl;
            isDead2 = true; 
            doneC2 = true; 
        }
    }
    return isDead;
}

/**
 * game played here, calls all functions
 * goes through all attacks and all map sequences
 */
int main()
{
    // variables to keep track of choice 
    string line;
    int choice1 = 0 ;
    string choice2;
    string choice3;
    bool done1 = false; 
    bool done2 = false; 
    bool done3 = false; 
    Stats optionS;
    Attack battle1;
    Attack battle2; 
    Attack finalB;
    Map Cave;
    Map Castle; 
    Map Castle2;
    string name;
    string name2; 
    Bag BagP;
    bool isKnight =false;
    Character PlayerM;
    bool isMage = false; 
    Enemy Regular;
    bool regular = false;
    bool boss = true; 
    Enemy Boss(boss);

    // first loop of the game, the first "third" of the game 
    while (!done1)
    {
        // menu for the player 
        cout << "Hello! Welcome to my Game." << endl; 
        cout << "Choose an Option:" << endl; 
        cout << "1. Start Game. " << endl; 
        cout << "2. Read recent player stats." << endl; 
        cout << "3. Read top player stats." << endl; 
        cout << "4. Find your stats." << endl; 
        cout << "5. Credits." << endl; 
        cout << "6. Quit Game." << endl; 
        cin >> choice1;
        cin.ignore();
        if (choice1 == 1)
        {
            // choice 1 is leads to choosing character 
            cout << "Choose your character!" << endl; 
            cout << "1. Mage or 2. Knight" << endl; 
            getline(cin,choice2); 
            if (choice2 == "1")         // chose the mage and sets the players stats
            {
                isMage = true; 
                cout << "Enter character name: " << endl; 
                getline(cin, name); 
                PlayerM.setNameM(name);  
                name2 = name;
                cout << "Are you ready Mage " << PlayerM.getNameM() << "?" << endl; 
                cout << "1 for yes, 2 for quit." << endl;  
                getline(cin,choice3);
                    if( choice3 == "1") 
                    {
                        done1 = true;   
                    }   
                    else if ( choice3 == "2")   
                    {
                        cout << "Goodbye!" << endl; 
                        return 0;
                    }            
            }
            else 
            {
                // chose tyhe knght and sets the players stats
                isKnight = true; 
                cout << "Enter character name: " << endl; 
                getline(cin,name); 
                PlayerM.setNameM(name);
                name2 = name;
                cout << "Are you ready Knight " << PlayerM.getNameM() << "?" << endl; 
                cout << "1 for yes, 2 for Quit." << endl;
                getline(cin,choice2);
                if( choice2 == "1") 
                    {
                        done1 = true;   
                    }   
                    else    
                    {
                        return 0;
                    }
            }  
        }
        else if (choice1 == 2) // finding most recent player stats
        {
            optionS.option2();
        }
        else if (choice1 == 3)  // read best stats
        {
            optionS.option3();
        }
        else if (choice1 == 4)   // reads then name that is enetered stats, brings the most recent players 
        {
            string playerName;
            cout << "Enter your name." << endl;
            getline(cin, playerName);
            optionS.option4(playerName);
        }
        else if (choice1 == 5)  // credits to the people who helped me 
        {
            cout << "Big shout out to my boy James, who helped me create the healthbar but I encountered so many problems and my tutor who helped me with writing some of my functions." << endl;
        }
        else if ( choice1 == 6) // quites the game 
        {
            cout << "Goodbye!" << endl; 
            return 0;
        }
    }
    while(!done2 && done1)
    {
        // secdn third of the game 
        string pathC;
        cout << "You wake up in a burned down house. You leave the house to see your city burned. You see two paths." << endl; 
        cout << "One path leads to the mountains, one leads to the Castle." << endl; 
        cout << "Which do you choose? Enter 1 for the Mountain, 2 for the road to the Castle." << endl; 
        getline(cin,pathC);
        while(pathC == "1") // path to the moutnatin 
        {
            cout << "You take your journey into the mountains in hopes of finding who was responsible." << endl; 
            cout << "While deep in the mountains you find a cave and enter." << endl; 
            mapCave(Cave, BagP);                                                                // calling the mapcave for the player 
            cout << "You've exited the cave and made your way back to the path" << endl; 
            pathC = "2";
        }
        if (pathC == "2")
        {
            // player skipped the cave and wewnt to the first fight 
            cout << "You take your first steps towards. Walking along the path you see what looks like a knight ahead." << endl;
            cout << "As you get closer you notice he does not wear the same colors, he notices you and challenges you." << endl; 
            int oldH = PlayerM.getHealthM();
            Attack(PlayerM, Regular, BagP);
            int isDead = battle1.Battle();
            int dead = oldH - isDead;
            if (dead > 0)       // updateas the player health due to an complexity with Attack funcitonality 
            {
                PlayerM.newdecHealthM(dead);
            }
            else if ( dead < 0)
            {
                PlayerM.newincHealthM(dead * -1);
            }
            if ( isDead == 0) // if your dead ends the game 
            {  
                return 0; 
            }
            else if (isDead > 0)
            { 
                // you killed the knight and move on twothe second map 
                cout << "You beat the Knight! Great job. You gained 4000 runes for deafeating him!" << endl;
                int rune1 = 4000;
                BagP.setRunes(rune1); 
                cout << "You ended the fight with " << PlayerM.getHealthM() << " HP."<< endl; 
                cout << "Would you like to heal?" << endl;                                      // allows player to hela after the fight 
                cout << "1 for Yes, 2 for No." << endl; 
                int healC = 0;
                cin >> healC;
                if (healC != 1 || healC != 2)                       // allows player to heal after battle 
                {
                    cout << "Please enter 1 or 2." << endl; 
                }
                else if (healC == 1)       //heals player 
                {
                    int health = 20;
                    int deac = 1;
                    //PlayerK.newincHealthK(health);
                    PlayerM.newincHealthM(health);
                    BagP.deacFlasks(deac);
                }
            }
            cout << "You continue on your path and enter the castle." << endl; 
            cout << "Traversing your way through the castle you encounter a burned down hall you must traverse." << endl;       // enters the second map of the game 
            mapCastle(Castle, BagP);
            done2 = true;       //exits the second third of the game 
        }

    }
    while(!done3 && done1 && done2)
    {
        //encounter a knight you have to sneeak oast 
        cout << "Moving on through the castle you hear footsteps, heavy breathing and the sound of a sword being swung." << endl; 
        cout << "You peak around the corner, a man standing without a helmet and burned armour is swinging his sword." << endl; 
        cout << " You try to sneak by." << endl; 
        if( mapCastle2(Castle2, PlayerM, BagP) == 0)     //checks to see if your dead not not
        {
            // //cout << PlayerM.getHealthM() << endl; 
            // int oldH = PlayerM.getHealthM();
            // int isDead = battle2.Battle();
            // int dead = oldH - isDead;
            // if (isDead > 0)
            // {
            //     PlayerM.newdecHealthM(dead);
            // }
            // else if ( isDead < 0)
            // {
            //     PlayerM.newincHealthM(dead * -1);           // udates players health 
            // }
            // if (isDead == 0)                        // checks for death of player 
            // {
            //     return 0;
            // }
            return 0;
        }
        else 
        {
            // allows player to heal before the boss battle 
            cout << "You ended the fight with " << PlayerM.getHealthM() << " HP."<< endl; 
            cout << "Would you like to heal?" << endl;                                      // allows player to hela after the fight 
            cout << "1 for Yes, 2 for No." << endl; 
            int healC = 0;
            cin >> healC;
            if (healC != 1 || healC != 2)
            {
                cout << "Please enter 1 or 2." << endl; 
            }
            else if (healC == 1)
            {
                int health = 20;
                int deac = 1;
                //PlayerK.newincHealthK(health);
                PlayerM.newincHealthM(health);
                BagP.deacFlasks(deac);
            }
            // final boss fight 
            cout << "Moving on from the knight you find the throne room." << endl; 
            cout << "You enter the room." << endl; 
            cout << "A man is there, a man of short stature. A goofy hat, and a weird voice." << endl; 
            cout << "The man turns around and reveals himself to be Lord Farquaad." << endl; 
            cout << "Ahh I see you have challenged me." << endl;
            Attack(PlayerM, Boss, BagP);                                // attackfunction for the battle 
            finalB.Battle();
            if (finalB.Battle() > 0)                // you won the final battle and beat the game your stats are appended the file 
            {
                cout << "Congrats! You beat the boss!" << endl; 
                cout << "Your final stats/runes were: " << PlayerM.getHealthM() << " HP, and " << BagP.getRunes() << " runes!" << endl;
                int stat12 = PlayerM.getHealthM();
                int stat13 = BagP.getRunes();
                string statName = PlayerM.getNameM(); 
                Stat finalStat(statName, stat12, stat13);
                optionS.addStat(finalStat);
                done3 = true;
            }
            else        // youn died 
            {
                done3 = true;
            }
        }
    }
    return 0;
}