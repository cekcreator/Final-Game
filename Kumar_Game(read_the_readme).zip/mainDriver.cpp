//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
#include <vector> 
#include "Bag.h"
#include "Mage.h"
#include "Knight.h"
#include "Enemy.h"

using namespace std; 

int main()
{
    // testing the enemy class 
    int HP = 0; 
    int damage = 35;
    bool boss = true;
    string ENEMY = "Dark Wolf" ;
    Enemy Boss = Enemy(boss); 
    cout << Boss.getHealthE() << endl;
    bool fuck = false;
    Enemy DarkWolf = Enemy(fuck);
    DarkWolf.setNameE(ENEMY);
    cout << DarkWolf.getNameE() << endl; 
    DarkWolf.newdecHealthE(damage);
    if (DarkWolf.getHealth(HP) == true)
    {
       cout << "Dead" << endl; 
    }
    else 
    {
        cout << "Alive" << endl; 
    }
    cout << DarkWolf.getHealthE() << endl; 
    int moreHP = 10;
    DarkWolf.newincHealthE(moreHP);  
    cout << DarkWolf.getHealthE() << endl;
    //testing Knight and Mage classes 
    Knight Caleb; 
    cout << Caleb.getHealthK() << endl; 
    string nameK = "Kaleb";
    Caleb.setNameK(nameK);
    // fix strength
    cout << Caleb.getNameK() << endl;
    int damage2 = 5;
    Caleb.newdecHealthK(damage2);
    cout << Caleb.getHealthK() << endl;
    cout << Caleb.getStrengthK() << endl;
    int Health = 10;
    Caleb.newincHealthK(Health);
    cout << Caleb.getHealthK() << endl;
    Mage CalebK; 
    cout << CalebK.getHealthM() << endl; 
    Bag KnightBag;
    int flask = 2;
    KnightBag.setFlasks(flask);
    cout << KnightBag.getFlasks() << endl;
    int runes = 100; 
    KnightBag.setRunes(runes); 
    cout << KnightBag.getRunes() << endl; 
    KnightBag.readOutItems();
    return 0; 
}