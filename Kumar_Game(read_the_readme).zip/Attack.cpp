//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include "Attack.h"
#include "Enemy.h"
#include "Character.h"
#include "time.h"
#include "Bag.h"
#include "Stat.h"
#include "Stats.h"
using namespace std; 

/**
 * takes in the ints and the players of the battle and prints out a helath bar for each side
 * takes in the health as ints and the prints out the number of correspodning "=" for the health bar 
 * takes in both names of charcters and displays them under the health bar 
 */
void heartBar(int num1, int num2, string name, string name2) 
{
    int uHealth = num1;
    int eHealth = num2;
    string name1 = name;
    string eName = name2;
    if (uHealth == 100)
    {
        cout << "100% ===========" << "> <";
    }
    else if (uHealth >= 10 && uHealth < 100)
    {
        int x = uHealth / 10; 
        cout << " " << uHealth << "% ";
        for (int j = 0; j < 10 - x; j++)
        {
            cout << " ";
        }
        for ( int i = 0; i < x; i++)
        {
            cout << "="; 
        }
        cout << "> <"; 
    }
    if (eHealth == 100)
    {
        cout << "========== 100%" << endl;  
    }
    else if ( eHealth >= 10 && eHealth < 100)
    {
        int E = eHealth / 10;
        for ( int e = 0; e < E; e++)
        {
            cout << "=";
        }
        for (int a = 0; a < 10 - E; a++)
        {
            cout << " ";
        }
        cout << eHealth << "%" << endl; 
    }
    int z = 35 - name1.length() - eName.length();
    cout << "You"; 
    for (int i = 0; i < z; i++)
    {
        cout << " ";
    }
    cout << eName << endl; 
}

// constructor intitalzing the battle count to zero 
Attack::Attack()
{
    battleCount = 0;
}

//intializes all varaibles and seeds the random function 
Attack::Attack(Character& player1, Enemy enemy1, Bag bag1)
{
    player = player1;
    enemy = enemy1; 
    bag = bag1;
    srand(time(0));
}

/**
 * attackfunction goes through the battle and gives the player and option to heal or attack, also displays a health bar for the player and the enemy
 * returns a bool vraiable to check and see if the player is dead or alive
 */
int Attack::Battle()
{
    Stats optionS;
    int isDead = 0; 
    int damage = 20;
    int damage2 = 25;
    int criticalD = 45; 
    while(player.getHealthM() > 0 && enemy.getHealthE() > 0) // checks for player alive 
    {
        heartBar(player.getHealthM(), enemy.getHealthE(), player.getNameM(), enemy.getNameE());
        cout << "Would you like to 1. Attack or 2. Heal?" << endl;                                  // attack option 
        string choice;
        cin >> choice; 
        if ( choice == "1")
        {
            int var1 = rand() % 10;                     // random chance for a critical hit attack
            if (var1 < 3)
            {
                cout << "You attacked with a criticle hit and did 45 damage!" << endl;
                enemy.newdecHealthE(criticalD);
            }
            else
            {
                cout << "You attacked and did 20 damage!" << endl;
                enemy.newdecHealthE(damage); 
            }
        }
        else if (choice == "2")         // heal option for healing with the flasks 
        {
            int heal = 30;
            int numFlask = 1;
            cout << "You healed with a flask for 30 points!" << endl; 
            player.newincHealthM(heal);
            bag.deacFlasks(numFlask); 
        }
        if (enemy.getHealthE() > 0)                 // checks the enemy health and if still alive the enemy will still do damage 
        {
            cout << "The enemy attacked you, and did 25 damage!" << endl; 
            player.newdecHealthM(damage2); 
        }
        if(player.getHealthM() == 0)        // if you die the battle is done 
        {
            cout << "Oh no! You died! Better luck next time, your stats will be added to a file." << endl; 
            int dead = 100;
            player.newdecHealthM(dead);
            int stat12 = player.getHealthM();
            int stat13 = bag.getRunes();
            string statName = player.getNameM(); 
            Stat finalStat(statName, stat12, stat13);
            optionS.addStat(finalStat);
        }
    }
    battleCount++;
    return player.getHealthM();
}