//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include "Enemy.h"

using namespace std;

// constructor for detemining the boss or the regular ebnemy 
Enemy::Enemy(bool BOSS)
{ 
    if (!BOSS)
    {
        name = "Knight";
        stre = 25;
        HPE = 100;
    }
    else 
    {
        name = "Final Boss";
        stre = 30;
        HPE = 120;
    }
}

//returns the enemy health
int Enemy::getHealthE()
{
    return HPE;
}

// returns the enemy name
string Enemy::getNameE()
{
    return name;
}

// returns the enenmy helath and if they are dead 
bool Enemy::getHealth(int HPE)
{
    if ( HPE <= 0)
    {
        HPE = 0;
        return true;
    }
    else 
    {
        return false; 
    }
}

// sets the enemy name
void Enemy::setNameE(string nameE)
{
    name = nameE; 
}

// increases the enemy health
void Enemy::newincHealthE(int incHP)
{
    HPE += incHP;
}

// deac the enenmy health 
void Enemy::newdecHealthE(int decHP)
{
    HPE -= decHP;
    if (HPE < 0)
    {
        HPE = 0;
    }
}