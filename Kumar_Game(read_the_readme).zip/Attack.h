//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <fstream>
#include "Character.h"
#include "Enemy.h"
#include "Bag.h"
#ifndef ATTACK_H
#define ATTACK_H
using namespace std;

class Attack
{
    public: 
        // constructor 
        Attack();
        // parameterized constrcutor 
        Attack(Character& , Enemy, Bag);
        // battle function doing the battle 
        int Battle();
    private:
        Character player;
        Enemy enemy; 
        Bag bag;
        int battleCount;
};
#endif