//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <fstream>
#ifndef CHARACTER_H
#define CHARACTER_H
using namespace std;

class Character
{
    public:
        // sets character toeither knight or mage
        Character(bool type = false);
        //Mage(string name, int HP, int stre); do i need this?? 
        //getters 
            // returns the name of the chracter 
            string getNameM();
            //returns the health of the player 
            int getHealthM();
            //attack function 
            int getAttack();
        //setters 
            // sets the character name 
            void setNameM(string);
            // ince the health 
            void newincHealthM(int);
            // deac the health of th eplayer 
            void newdecHealthM(int);


        private:
            string _name;
            int HP; 
            int battleA;
            int power;
};
#endif 