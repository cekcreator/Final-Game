//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <fstream>
#ifndef ENEMY_H
#define ENEMY_H
using namespace std;

class Enemy
{
    public:
        // constructor for determining a regular or boss enemy 
        Enemy(bool BOSS = false);
        //getters 
            // checks for enemy death 
            bool getHealth(int);
            // gets the enemy name 
            string getNameE();
            // gets the enemy heqlth 
            int getHealthE();

        //setters 
            // set the enemyt name 
            void setNameE(string);
            // inc the enemy health 
            void newincHealthE(int);
            // deac the enemy health 
            void newdecHealthE(int);

    private:
        string name; // name variable 
        int HPE;  // health 
        int stre; // strenght
        int _attE; // attack power
        int bossAttack; // boss attack power
};
#endif 