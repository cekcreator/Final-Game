//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <fstream>
#include "Character.h"
#include "Enemy.h"
#include "Bag.h"
#include "Attack.h"
#include "Stat.h"
#ifndef STATS_H
#define STATS_H
using namespace std;

class Stats
{
    public:
        //adding the stats 
        Stats();
        void option2();
        void option3();
        void option4(string);
        void addStat(Stat);

    private:
        //VECTOR OF OBJECTS FROM STAT CLASS STATS AND STAT ARE TWO DIFFERENT CLASSES
        vector<Stat> stats1;

};
#endif