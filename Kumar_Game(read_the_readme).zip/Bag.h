//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <fstream>
#include <vector>
#ifndef BAG_H
#define BAG_H
using namespace std;

class Bag
{
    public:
    Bag(); 
    //getters 
        int getFlasks();
        int getRunes();
        void readOutItems();
    
    //SETTERS
        void setFlasks(int);
        void setRunes(int);
        void setItems(string);
        void deacFlasks(int);

    private:
        int numFlasks; 
        int runes; 
        vector<string> items; 
        // needs vector 

};
#endif 