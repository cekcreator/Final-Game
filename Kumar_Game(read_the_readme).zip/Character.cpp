//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include "Character.h"

using namespace std;

// constrcuter setting the type of character chosen 
Character::Character(bool type)
{  
    //knight = Knight; 
    if (!type)
    {
        power = 35;
        HP = 100;
        battleA = 0;
    }
    else //mage 
    {
        power = 35;
        HP = 100;
        battleA = 0;
    }
}

//returns the chracters name 
string Character::getNameM()
{
    return _name;
}

//returns the health of the chracter 
int Character::getHealthM()
{
    return HP;
}

//sets the chracter name 
void Character::setNameM(string name)
{
    _name = name; 
    // maybe check for empty string ask TA
}

//inc the player 
void Character::newincHealthM(int incHP)
{
    HP += incHP;
}

//deac the player health 
void Character::newdecHealthM(int damage)
{
    HP -=  damage;
    if ( HP < 0)
    {
        HP = 0; 
    }
}
