//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include "Attack.h"
#include "Enemy.h"
#include "Character.h"
#include "time.h"
#include "Bag.h"
#include "Stat.h"
using namespace std; 

//constructor setting the varibales equal to the given varaibels 
Stat::Stat(string name1, int health1, int runes1)
{
    name = name1;
    health = health1;
    runes = runes1; 
}

// returns the string of the stats wanted 
string Stat::toString()
{ 
    return name + ": HP - " + to_string(health) + " Runes - " + to_string(runes);
}

//returns the player the stat belongs too 
string Stat::getName()
{
    return name;
}

// writies to the file of the string 
string Stat::toFile()
{
    return name +  "," + to_string(health) + "," + to_string(runes);
}