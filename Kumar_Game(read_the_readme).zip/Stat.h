//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 3 CYO

#include <iostream>
#include <fstream>
#include "Character.h"
#include "Enemy.h"
#include "Bag.h"
#include "Attack.h"
#ifndef STAT_H
#define STAT_H
using namespace std;

class Stat
{
    public:
        // public functions
        Stat(string, int, int);
        string toString();
        string getName();
        string toFile();
    private:
        //PRIVATE VARAIBLES
        string name; 
        int health;
        int runes; 
};
#endif 